import React from 'react';
import "./currentLocation.css"

const CurrentLocation = () => {

    //geolocation api
    const apiKey = "AIzaSyDrJZbY80fJate2d6UVm75j8rmqlYXbUiI";

    return (
        <div>
            
        </div>
    );
};

export default CurrentLocation;