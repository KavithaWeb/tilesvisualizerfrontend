export const coupons = [
   {
       id: 1,
       coupon_code: "KOTAK125",
       coupon_heading: "Get 20% discount using Kotak Bank Cards",
       coupon_desc : "Maximum discount up to  ₹125 on orders above ₹500",
       bank_logo: "https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_40,h_40/rng/md/ads/production/ve29grh1iofiwu4hiyei"
   },
   {
    id: 2,
    coupon_code: "UBI100",
    coupon_heading: "Get 20% discount using Kotak Bank Cards",
    coupon_desc : "Maximum discount up to  ₹125 on orders above ₹500",
    bank_logo: "https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_40,h_40/rng/md/ads/production/lendxe1cnoyszqvotvok"
},
{
    id: 3,
    coupon_code: "PAYTMBANK150",
    coupon_heading: "Get 20% discount using Kotak Bank Cards",
    coupon_desc : "Maximum discount up to  ₹125 on orders above ₹500",
    bank_logo: "https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_40,h_40/rng/md/ads/production/wcjdhfxoextwffqvuwpy"
},
{
    id: 4,
    coupon_code: "POSTPE",
    coupon_heading: "Get 20% discount using Kotak Bank Cards",
    coupon_desc : "Maximum discount up to  ₹125 on orders above ₹500",
    bank_logo: "https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_40,h_40/rng/md/ads/production/bdewk0rti8oulj22crry"
},
{
    id: 5,
    coupon_code: "INDUSIND20",
    coupon_heading: "Get 20% discount using Kotak Bank Cards",
    coupon_desc : "Maximum discount up to  ₹125 on orders above ₹500",
    bank_logo: "https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_40,h_40/rng/md/ads/production/rzv7tw0y62tlcvi3cir7"
},
{
    id: 6,
    coupon_code: "PNBWEEKEND",
    coupon_heading: "Get 20% discount using Kotak Bank Cards",
    coupon_desc : "Maximum discount up to  ₹125 on orders above ₹500",
    bank_logo: "https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_40,h_40/rng/md/ads/production/fhwpvgllsjjyguscawmv"
},
{
    id: 7,
    coupon_code: "RUPAY100",
    coupon_heading: "Get 20% discount using Kotak Bank Cards",
    coupon_desc : "Maximum discount up to  ₹125 on orders above ₹500",
    bank_logo: "https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_40,h_40/rng/md/ads/production/bbgxg0mcsiagum0lpxil"
},
{
    id: 8,
    coupon_code: "CITIFOODIE",
    coupon_heading: "Get 20% discount using Kotak Bank Cards",
    coupon_desc : "Maximum discount up to  ₹125 on orders above ₹500",
    bank_logo: "https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_40,h_40/rng/md/ads/production/wmbq0mrieb0qahxnglfp"
},
{
    id: 9,
    coupon_code: "PAYTMSAVE",
    coupon_heading: "Get 20% discount using Kotak Bank Cards",
    coupon_desc : "Maximum discount up to  ₹125 on orders above ₹500",
    bank_logo: "https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_40,h_40/rng/md/ads/production/peav5nlqlsdxrzix1ibc"
}
]