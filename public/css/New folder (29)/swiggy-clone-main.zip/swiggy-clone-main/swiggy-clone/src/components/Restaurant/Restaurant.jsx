import React from 'react'
import Header from './Header'

const Restaurant = () => {
  return (
    <div><Header/></div>
  )
}

export default Restaurant