import React from 'react';
import "./pagenotfound.css";

const PagenotFound = () => {
    return (
        <div>
<div class="container">
    <h1 class="four">4</h1>
      <img class="cog-wheel1 loading" src="landingImages/wheel1.png" alt=""  />
   <h1 class="four">4</h1>
  </div>
  <p class="wrong-para">Uh Oh! Page not found!</p>

        </div>
    );
};

export default PagenotFound;



