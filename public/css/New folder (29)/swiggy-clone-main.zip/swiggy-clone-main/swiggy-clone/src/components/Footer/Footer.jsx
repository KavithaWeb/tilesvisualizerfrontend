import React from 'react'
import './Footer.css'

function Footer() {
  return (
    <div className='footer_container'>
      <h1>HELLO SWIGGY, I AM FOOTER</h1> 
    </div>
  )
}

export default Footer
