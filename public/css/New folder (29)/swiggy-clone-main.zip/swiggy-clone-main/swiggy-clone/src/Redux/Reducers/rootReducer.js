import { combineReducers } from "redux";
import { foodItemsReducer } from "./foodItemReducer";

export const rootReducer = combineReducers({
    foodItemsReducer
})