import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';


platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.error(err));



// {
//   title: "",
//   rate: ,
//   img2: "",
//   img1: "",
//   img3:"",
//   Pages: ,
//   Language: "",
//   author: ""
//   comments:[{
//     name: "",
//     comment: ""
//   }]
// }
// {
//   title: "",
//   rate: ,
//   img2: "",
//   img1: "",
//   img3:"",
//   Pages: ,
//   Language: "",
//   author: ""
//   comments:[{
//     name: "",
//     comment: ""
//   }]
// }
// {
//   title: "",
//   rate: ,
//   img2: "",
//   img1: "",
//   img3:"",
//   Pages: ,
//   Language: "",
//   author: ""
//   comments:[{
//     name: "",
//     comment: ""
//   }]
// }
// {
//   title: "",
//   rate: ,
//   img2: "",
//   img1: "",
//   img3:"",
//   Pages: ,
//   Language: "",
//   author: ""
//   comments:[{
//     name: "",
//     comment: ""
//   }]
// }
// {
//   title: "",
//   rate: ,
//   img2: "",
//   img1: "",
//   img3:"",
//   Pages: ,
//   Language: "",
//   author: ""
//   comments:[{
//     name: "",
//     comment: ""
//   }]
// }
// {
//   title: "",
//   rate: ,
//   img2: "",
//   img1: "",
//   img3:"",
//   Pages: ,
//   Language: "",
//   author: ""
//   comments:[{
//     name: "",
//     comment: ""
//   }]
// }